CARA PAKAI

1. Copy peta.html ke folder project kamu dan replace peta.html lama.
2. Copy folder assets/data berikut ke folder project kamu.
3. Pastikan file ini ada:
   assets/data/kota_yogyakarta_admin.zip
   assets/data/kota_yogyakarta_admin.geojson
4. Buka lewat VS Code Live Server / GitHub Pages, bukan double click file HTML biasa.

Catatan:
- File kota_yogyakarta_admin.zip adalah hasil penyederhanaan dari KOTA YOGYAKARTA.zip, hanya mengambil layer ADMINISTRASIDESA_AR_25K supaya terbaca stabil di browser.
- GeoJSON disertakan sebagai cadangan otomatis kalau ZIP/shpjs gagal dibaca.
